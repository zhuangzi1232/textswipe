# 文字触发上滑（Android 源码）

**只有一个功能**：屏幕上一出现你设定的任意文字，就自动上滑一次。

## 它怎么做到「精准」

- **通道 1｜界面文字节点**：直接读系统无障碍树里的文字，逐字比对，100% 精准、几乎不耗电。
- **通道 2｜截屏中文 OCR 兜底**：有些 App 把提示文字自己画在画面上（无障碍读不到），这时每 1.2 秒截一次屏，用离线中文模型识别。
- **三道防误触**：只认屏幕下半部的文字；单行超过 60 字不认；触发后 5 秒冷却（一条广告只滑一次，不会把正片划走）。

要求：Android 11（API 30）及以上，iQOO / OriginOS 可用。**不需要 Root，不需要 Google Play 服务。**

## 编译安装

1. 用 Android Studio 打开 `TextTriggerSwipe` 这个目录（会按 `gradle/wrapper/gradle-wrapper.properties` 自动使用 Gradle 8.7）。
2. 如果 `google()` 仓库拉不动，把 `settings.gradle.kts` 里两行阿里云镜像的注释放开。
3. 如果 `com.google.mlkit:text-recognition-chinese:16.0.1` 始终拉不到：删掉 `app/build.gradle.kts` 里那行依赖，并把 `SwipeService.kt` 的 `ENABLE_OCR` 改成 `false`，程序仍可用通道 1 正常工作。
4. 点运行，装到手机上，桌面出现「文字触发上滑」。

## 使用（iQOO）

1. 打开 App，输入框里**每行填一个词**，建议填完整短句，例如：

   ```text
   上滑继续观看短剧
   上滑继续观看
   继续观看短剧
   ```

   点「保存关键词」。词越完整越不容易误触，别只填「上滑」两个字。
2. `设置 → 快捷与辅助 → 无障碍 → 已下载的服务 → 文字触发上滑 → 打开 → 确定`
   （开关是灰的点不动：长按桌面图标 → 应用信息 → 右上角「…」→ 允许受限制的设置）
3. 保活三件套，不然看两集就被系统杀掉：
   - `设置 → 电池 → 后台高耗电 → 允许`
   - `i管家 → 应用管理 → 权限管理 → 权限 → 自启动 → 允许`
   - 多任务界面把本 App 卡片向下拉一下，出现小锁 = 加白名单
4. 回到红果，等广告倒计时结束、底部出现那行字时，它会自动上滑一次。

## 可调参数

都在 `SwipeService.kt` 顶部 `companion object` 里：

| 参数 | 默认 | 作用 |
|---|---|---|
| `COOLDOWN_MS` | 5000 | 两次触发的最小间隔（毫秒） |
| `ONLY_BOTTOM` | true | 只认下半屏文字 |
| `OCR_INTERVAL_MS` | 1200 | 截屏识别间隔，调大更省电 |
| `MAX_TEXT_LEN` | 60 | 单行超过这个字数不认 |
| `TARGET_PACKAGE` | 空 | 填包名可限定只在某个 App 生效，留空 = 全局 |

## 注意

- 默认全局生效，别的应用里出现同样文字也会滑；把关键词写完整，或填 `TARGET_PACKAGE` 限定范围。
- 不用时去 `无障碍 → 已下载的服务` 把开关关掉，顺手关掉「后台高耗电」。
- 无障碍权限允许应用读屏和代你操作，请只装自己编译的这份源码。
- 仅供个人辅助操作，勿用于刷量、作弊等违反平台规则的用途。

## 文件清单

```text
settings.gradle.kts / build.gradle.kts / gradle.properties
gradle/wrapper/gradle-wrapper.properties
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/yuanbao/textswipe/MainActivity.kt     设置界面
app/src/main/java/com/yuanbao/textswipe/SwipeService.kt    核心：识别 + 上滑
app/src/main/res/xml/accessibility_service_config.xml
app/src/main/res/values/strings.xml
```
