package com.yuanbao.textswipe

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import java.util.concurrent.Executor

/**
 * 唯一功能：屏幕上一出现用户设定的文字，就执行一次上滑。
 * 通道 1：读无障碍文字节点（零耗电、100% 精准）
 * 通道 2：截屏中文 OCR 兜底（文字被 App 自绘、读不到节点时也能认）
 */
class SwipeService : AccessibilityService() {

    companion object {
        private const val TAG = "TextSwipe"

        // ---- 可调参数 ----
        private const val ENABLE_OCR = true       // 拉不到 ML Kit 就改成 false，只用通道 1
        private const val ONLY_BOTTOM = true      // 只认屏幕下半部的文字，防止把台词当提示
        private const val COOLDOWN_MS = 5000L    // 触发后 5 秒内不重复滑，避免连滑划走正片
        private const val OCR_INTERVAL_MS = 1200L
        private const val MAX_TEXT_LEN = 60      // 太长的段落不参与匹配
        private const val TARGET_PACKAGE = ""    // 只想在某个 App 生效就填包名；留空 = 全局
    }

    private val handler = Handler(Looper.getMainLooper())
    private val mainExecutor = Executor { runnable -> handler.post(runnable) }
    private var recognizer: TextRecognizer? = null
    private var alive = false
    private var ocrBusy = false
    private var lastTriggerAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        alive = true
        if (ENABLE_OCR) {
            recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            handler.postDelayed(ocrLoop, 800L)
        }
        Log.d(TAG, "服务已连接")
    }

    // ---------------- 通道 1：界面文字节点 ----------------
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !alive || !isScreenOn()) return
        val type = event.eventType
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) return
        if (!inTargetApp(event.packageName?.toString())) return
        scan(rootInActiveWindow)
    }

    private fun scan(node: AccessibilityNodeInfo?) {
        if (node == null || !alive) return

        val texts = listOf(
            node.text?.toString()?.trim().orEmpty(),
            node.contentDescription?.toString()?.trim().orEmpty()
        )
        for (s in texts) {
            if (s.length in 1..MAX_TEXT_LEN && hit(s)) {
                val r = Rect()
                node.getBoundsInScreen(r)
                if (!ONLY_BOTTOM || r.top >= screenH() / 2) {
                    fire("界面文字：$s")
                    return
                }
            }
        }

        for (i in 0 until node.childCount) {
            scan(node.getChild(i))
        }
    }

    // ---------------- 通道 2：截屏 OCR 兜底 ----------------
    private val ocrLoop = object : Runnable {
        override fun run() {
            if (!alive) return
            if (!ocrBusy && isScreenOn() && inTargetApp(currentPackage())) {
                screenshotAndRecognize()
            }
            handler.postDelayed(this, OCR_INTERVAL_MS)
        }
    }

    private fun screenshotAndRecognize() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        ocrBusy = true
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        try {
                            val buffer = result.hardwareBuffer
                            val src = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                            val bmp = src?.copy(Bitmap.Config.ARGB_8888, false)
                            buffer.close()
                            if (bmp == null) {
                                ocrBusy = false
                                return
                            }
                            val image = InputImage.fromBitmap(bmp, 0)
                            recognizer?.process(image)
                                ?.addOnSuccessListener { text -> checkOcr(text, bmp.height) }
                                ?.addOnCompleteListener { bmp.recycle(); ocrBusy = false }
                                ?: run { bmp.recycle(); ocrBusy = false }
                        } catch (e: Throwable) {
                            ocrBusy = false
                            Log.w(TAG, "截屏识别失败", e)
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        ocrBusy = false
                        Log.w(TAG, "截屏失败，错误码 $errorCode")
                    }
                }
            )
        } catch (e: Throwable) {
            ocrBusy = false
            Log.w(TAG, "无法截屏", e)
        }
    }

    private fun checkOcr(text: Text, height: Int) {
        for (block in text.textBlocks) {
            for (line in block.lines) {
                val s = line.text.trim()
                if (s.isEmpty() || s.length > MAX_TEXT_LEN || !hit(s)) continue
                val box = line.boundingBox
                if (!ONLY_BOTTOM || box == null || box.top >= height / 2) {
                    fire("截屏文字：$s")
                    return
                }
            }
        }
    }

    // ---------------- 匹配 + 上滑 ----------------
    private fun hit(text: String): Boolean =
        words().any { it.isNotEmpty() && text.contains(it) }

    private fun words(): List<String> =
        getSharedPreferences(MainActivity.PREF, MODE_PRIVATE)
            .getString(MainActivity.KEY_WORDS, MainActivity.DEFAULT_WORDS)
            .orEmpty()
            .split('\n', '\r')
            .map { it.trim() }
            .filter { it.isNotEmpty() }

    private fun fire(reason: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastTriggerAt < COOLDOWN_MS) return
        lastTriggerAt = now

        val w = screenW().toFloat()
        val h = screenH().toFloat()
        val path = Path().apply {
            moveTo(w * 0.5f, h * 0.80f)
            lineTo(w * 0.5f, h * 0.25f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 350L))
            .build()
        dispatchGesture(gesture, null, null)
        Log.d(TAG, "已上滑 ← $reason")
    }

    // ---------------- 小工具 ----------------
    private fun inTargetApp(pkg: String?): Boolean =
        TARGET_PACKAGE.isEmpty() || pkg == TARGET_PACKAGE

    private fun currentPackage(): String? = rootInActiveWindow?.packageName?.toString()

    private fun isScreenOn(): Boolean =
        getSystemService(PowerManager::class.java)?.isInteractive == true

    private fun screenW(): Int = resources.displayMetrics.widthPixels
    private fun screenH(): Int = resources.displayMetrics.heightPixels

    override fun onInterrupt() {}

    override fun onDestroy() {
        alive = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.close()
        recognizer = null
        super.onDestroy()
    }
}
