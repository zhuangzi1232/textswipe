package com.yuanbao.textswipe

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var editor: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dp = resources.displayMetrics.density
        fun d(v: Int) = (v * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(20), d(28), d(20), d(20))
        }

        root.addView(TextView(this).apply {
            text = "文字触发上滑"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "屏幕上一出现下面任意一行文字，就自动上滑一次。\n" +
                   "建议填完整短句（例：上滑继续观看短剧），越完整越不容易误触。"
            textSize = 14f
            setPadding(0, d(10), 0, d(16))
        })

        editor = EditText(this).apply {
            hint = "每行一个关键词"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 5
            gravity = Gravity.TOP or Gravity.START
            setText(prefs().getString(KEY_WORDS, DEFAULT_WORDS))
        }
        root.addView(
            editor,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        root.addView(Button(this).apply {
            text = "保存关键词"
            setOnClickListener {
                prefs().edit().putString(KEY_WORDS, editor.text.toString()).apply()
                Toast.makeText(this@MainActivity, "已保存", Toast.LENGTH_SHORT).show()
            }
        })

        status = TextView(this).apply {
            textSize = 14f
            setPadding(0, d(18), 0, d(12))
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "去开启无障碍服务"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        root.addView(TextView(this).apply {
            text = "iQOO 路径：设置 → 快捷与辅助 → 无障碍 → 已下载的服务 → 文字触发上滑 → 打开\n" +
                   "保活建议：设置 → 电池 → 后台高耗电 → 允许；i管家 → 权限管理 → 自启动 → 允许；" +
                   "多任务界面把本 App 卡片下拉加锁。"
            textSize = 13f
            setPadding(0, d(16), 0, 0)
        })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (isServiceEnabled()) {
            "● 服务已开启，正在监听"
        } else {
            "○ 服务未开启，请点下方按钮授权"
        }
    }

    private fun Context.prefs() = getSharedPreferences(PREF, MODE_PRIVATE)

    private fun isServiceEnabled(): Boolean {
        val flat = ComponentName(this, SwipeService::class.java).flattenToString()
        val list = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return list.split(':').any {
            it.equals(flat, ignoreCase = true) || it == "$packageName/.SwipeService"
        }
    }

    companion object {
        const val PREF = "textswipe"
        const val KEY_WORDS = "words"
        const val DEFAULT_WORDS = "上滑继续观看短剧\n上滑继续观看\n继续观看短剧"
    }
}
