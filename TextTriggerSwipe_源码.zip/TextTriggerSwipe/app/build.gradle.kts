plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.yuanbao.textswipe"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.yuanbao.textswipe"
        minSdk = 30          // 截屏 OCR 需要 Android 11+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // 中文 OCR 兜底：离线模型（约 20MB），不需要 Google Play 服务
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    // 若这个依赖始终拉不到：删掉上面一行，
    // 并把 SwipeService.kt 里的 ENABLE_OCR 改成 false，
    // 程序仍可用「无障碍文字节点」精准识别。
}
